from pymongo import MongoClient
import pandas as pd
import os

# Connect to MongoDB
try:
    client = MongoClient("mongodb://localhost:27017/")  # Establish connection to MongoDB
    db = client['survey_tool']  # Select the 'survey_tool' database
    users = db['users']  # Select the 'users' collection
    print("MongoDB connection successful!")
except Exception as e:
    print(f"Error connecting to MongoDB: {e}")
    # Exit the script if MongoDB connection fails
    exit(1)

# Fetch data from MongoDB
try:
    user = list(users.find({}, {"_id": 0}))  # Fetch all users, excluding the '_id' field
    if not user:
        print("No data found in MongoDB.")
    else:
        # Convert to DataFrame and save as CSV
        df = pd.DataFrame(user)  # Convert the list of users to a pandas DataFrame
        # Ensure the 'data' directory exists before saving the file
        os.makedirs('data', exist_ok=True)
        df.to_csv('data/users.csv', index=False)  # Save DataFrame to CSV file
        print("Data exported successfully to data/users.csv.")
except Exception as e:
    print(f"Error fetching or exporting data: {e}")
    # Exit the script if there is an error fetching or saving the data
    exit(1)
