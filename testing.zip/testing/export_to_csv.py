from pymongo import MongoClient
import pandas as pd
import os


# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client['survey_tool']
users = db['users']

# Fetch data from MongoDB
user = list(users.find({}, {"_id": 0}))

if not user:
    print("No data found in MongoDB.")
else:
    # Convert to DataFrame and save as CSV
    df = pd.DataFrame(user)
    df.to_csv('data/users.csv', index=False)
    print("Data exported successfully to data/users.csv.")
