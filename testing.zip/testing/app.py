from flask import Flask, render_template, request, redirect, url_for, make_response
from pymongo import MongoClient

app = Flask(__name__)

# MongoDB Configuration
try:
    client = MongoClient("mongodb://localhost:27017/")  # Connect to MongoDB
    db = client['survey_tool']  # Select the database
    users = db['users']  # Select the collection for users
    print("MongoDB connection successful!")
except Exception as e:
    print(f"Error connecting to MongoDB: {e}")
    # Gracefully handle the error, but allow the app to continue running
    users = None

@app.route('/', methods=['GET', 'POST'])
def index():
    # Handle POST requests (form submissions)
    if request.method == 'POST':
        try:
            # Log form data to the terminal for debugging purposes
            print(request.form)

            # Collect form data
            data = {
                'name': request.form['name'],
                'age': request.form['age'],
                'gender': request.form['gender'],
                'total_income': request.form['total_income'],
                'expenses': {
                    'utilities': float(request.form.get('utilities', 0)),
                    'entertainment': float(request.form.get('entertainment', 0)),
                    'school_fees': float(request.form.get('school_fees', 0)),
                    'shopping': float(request.form.get('shopping', 0)),
                    'healthcare': float(request.form.get('healthcare', 0)),
                    'housing': float(request.form.get('housing', 0)),
                    'transportation': float(request.form.get('transportation', 0)),
                    'miscellaneous': float(request.form.get('miscellaneous', 0))
                }
            }

            # Check if users collection exists and insert data
            if users is not None:
                users.insert_one(data)  # Insert the data into MongoDB collection
                print("Data inserted successfully.")
            else:
                print("Error: MongoDB connection is not available.")
            
        except Exception as e:
            print(f"Error processing form data: {e}")
            # Return an error message if form data processing fails
            return "There was an error processing the form. Please try again later."

        # Redirect to home page after form submission
        return redirect(url_for('index'))

    # Handle GET requests (display users and the empty form)
    try:
        all_users = users.find()  # Retrieve all users from the database
    except Exception as e:
        print(f"Error fetching users from the database: {e}")
        all_users = []  # If there’s an error, display an empty list

    # Render the page with an empty form for GET requests
    return render_template('index.html', users=all_users)

@app.route('/submit', methods=['POST'])
def submit():
    # Handle form submissions for the '/submit' route
    try:
        # Process the form data
        data = request.form.to_dict()  # Convert form data to a dictionary
        print(data)  # Log form data for debugging
        return "Form submitted successfully!"  # Temporary response for testing submission
    except Exception as e:
        print(f"Error processing form submission: {e}")
        return "Error occurred during form submission."

    # Prevent browser caching
    response = make_response(render_template('index.html'))
    response.headers['Cache-Control'] = 'no-store'
    return response

if __name__ == '__main__':
    # Run the Flask app in debug mode
    try:
        app.run(debug=True)
    except Exception as e:
        print(f"Error starting the Flask app: {e}")
