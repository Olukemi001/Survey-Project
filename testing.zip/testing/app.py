from flask import Flask, render_template, request, redirect, url_for         
from pymongo import MongoClient  
                                                                                                                   

app = Flask(__name__)                                                        
# MongoDB Configuration                                                      
client = MongoClient("mongodb://localhost:27017/")                           
db = client['survey_tool']                                                   
users = db['users']                                                 



@app.route('/', methods=['GET', 'POST'])                                     
def index():                                                                 
    if request.method == 'POST':
        print(request.form)  # Log the form data to the terminal                                             
        # Collect form data                                                  
        data = { 
            'name': request.form['name'],                                   
            'age': request.form['age'],                                      
            'gender': request.form['gender'],                                
            'total_income': request.form['total_income'],                    
            'expenses': {                                                    
                'utilities': float(request.form.get('utilities', 0)),        
                'entertainment': float(request.form.get('entertainment', 0)),
                'school_fees': float(request.form.get('school_fees', 0)),    
                'shopping': float(request.form.get('shopping', 0)),          
                'healthcare': float(request.form.get('healthcare', 0)),
                'housing': float(request.form.get('housing', 0)),              
                'transportation': float(request.form.get('transportation', 0)),
                'miscellaneous': float(request.form.get('miscellaneous', 0))       
            }                                                                
        }                                                                    
                                                                             
        # Insert into MongoDB                                                
        users.insert_one(data)                                          


        # Redirect to home page after form submission                                                                     
        return redirect(url_for('index')) 
    all_users = users.find()

                                      
    # Render the page with an empty form for GET requests                                                                         
    return render_template('index.html', users=all_users) 

@app.route('/submit', methods=['POST'])
def submit():
    # Process the form data
    data = request.form.to_dict()
    print(data)  # Log form data for debugging
    return "Form submitted successfully!"  # Temporary response to test submission

    # Prevent browser caching
    response = make_response(render_template('index.html'))
    response.headers['Cache-Control'] = 'no-store'
    return response
                                  
                                                                                                              
if __name__ == '__main__':                                                   
    app.run(debug=True)  


